export { default } from './TabBarIcon';
