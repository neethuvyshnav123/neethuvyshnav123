import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
    container: {
        color: 'red',
        paddingLeft: 15,
        fontSize: 12
    }
});
